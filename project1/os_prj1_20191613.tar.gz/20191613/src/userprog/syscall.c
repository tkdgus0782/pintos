#include "userprog/syscall.h"
#include <stdio.h>
#include <stdlib.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "threads/synch.h"

void cad(void*);
static void syscall_handler(struct intr_frame *);

void
syscall_init (void) 
{	
	intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

/* check whether given address is user area;
otherwise exit process (i.e., inbetween 0x8048000~0xc0000000) */
void cad(void* ptr){
	if(!is_user_vaddr(ptr) || ptr == NULL){
			exit(-1);
	}
}

/*
static void get_argument(void *esp, int *arg, int count){
}
*/

static void
syscall_handler (struct intr_frame *f) 
{
	//check whether esp and ptr are user space; otherwise page fault
	//getting syscall num from user stack
  int scn = * (uint32_t *) f->esp;
	switch(scn){
		/*save return to eax*/
    		case SYS_HALT:
			halt();
			break;
			
		case SYS_EXIT:
			cad(f->esp + 4);
			exit(*(uint32_t *)(f->esp + 4));
			break;
			
		case SYS_EXEC:
			cad(f->esp+4);
      f->eax = exec((const char *)*(uint32_t *)(f->esp + 4));
			break;
			
		case SYS_WAIT:
			cad(f->esp+4);
      f->eax = wait((pid_t)*(uint32_t *)(f->esp + 4));
			break;
			
		case SYS_CREATE:
			break;
			
		case SYS_REMOVE:
			break;
			
		case SYS_OPEN:
			break;
			
		case SYS_FILESIZE:
			break;
			
		case SYS_READ:
			cad(f->esp + 4);
			cad(f->esp + 8);
			cad(f->esp + 12);
			f->eax = read((int)*(uint32_t *)(f->esp + 4), (void *)*(uint32_t *)(f->esp + 8), (unsigned)*((uint32_t *)(f->esp + 12)));
			break;
			
		case SYS_WRITE:
			cad(f->esp + 4);
			cad(f->esp+8);
			cad(f->esp+12);
			f->eax = write((int)*(uint32_t *)(f->esp + 4), (void *)*(uint32_t *)(f->esp + 8), (unsigned)*((uint32_t *)(f->esp + 12)));
			break;
			
		case SYS_SEEK:
			break;
			
		case SYS_TELL:
			break;
			
		case SYS_CLOSE:
			break;
		case SYS_FIBONACCI:
			cad(f->esp + 4);
			f->eax = fibonacci((int)*(uint32_t *)(f->esp+4));
			break;
		case SYS_MAX_OF_FOUR_INT:

			f->eax = max_of_four_int((int)*(uint32_t *)(f->esp + 4), (int)*(uint32_t *)(f->esp + 8), 
					(int)*((uint32_t *)(f->esp + 12)),(int)*(uint32_t *)(f->esp + 16));
			break;
					
	}
}

void halt(void){
	shutdown_power_off();
}

void exit(int status){
	printf("%s: exit(%d)\n", thread_name(), status);
	thread_current()->exit_status = status;
	thread_exit();
}

/* create child process
uese process_execute in userprog/process.c */
pid_t exec (const char *file){
	return process_execute(file);
}

int wait (pid_t pid){
	return process_wait(pid);
}

int fibonacci(int n){
  
	int m1=0, now=1, temp;
 
      	for(int i = 1; i < n; i++){
		temp = now;
		now = now + m1;
		m1 = temp;
	}
	return now;
}

int max_of_four_int(int a, int b, int c, int d){
	int max = a;
	if(b > a){
		max = b;
	}
	if(c > max){
		max = c;
	}
	if(d > max){
		max = d;
	}
	return max;
}

int read (int fd, void *buffer, unsigned length){
  if(fd == 0){
	 char temp = input_getc();
	 while(temp!=0){
		 temp = input_getc();
	 }
	 return temp;

  }
  exit(-1);
}
int write (int fd, const void *buffer, unsigned length){
	if (fd == 1) {
		putbuf(buffer, length);
		return length;
	}
	exit(-1);
}
