#include "vm/page.h"
#include "threads/pte.h"
#include "userprog/pagedir.h"
#include "devices/block.h"
#include "userprog/syscall.h"
#include <stdio.h>
#include <string.h>

//struct block* sb;

unsigned hash_page(const struct hash_elem* e, void* aux UNUSED){//return hash
	const struct page* pte = hash_entry(e, struct page, hash_elem);
	return hash_int((int)pte->ua); 
}
unsigned hash_frame(const struct hash_elem* e, void* aux UNUSED){
	const struct page* fte = hash_entry(e,struct page, hash_elem);
	return hash_int((int)fte->ka);
}
bool hash_less(const struct hash_elem* a, const struct hash_elem* b, void* aux UNUSED){//a<B: true, else: false
	const struct page* ae = hash_entry(a, struct page, hash_elem);
	const struct page* be = hash_entry(b, struct page, hash_elem);
	return ae->ua < be->ua;
}
struct spt* page_table_init(){
	struct thread* t = thread_current();
	struct spt* spt = malloc(sizeof(struct spt));
	hash_init(&(spt->page_table), hash_page, hash_less, NULL);
//	hash_init(&(spt->frame_table), hash_frame, hash_less, NULL);
	//spt->swap_page = palloc_get_page(0);
	lock_init(&spt->frame_lock);
	lock_init(&spt->swap_out_lock);
	lock_init(&spt->evict_lock);
	lock_init(&spt->swap_in_lock);
	return spt;
}

struct page* page_find(struct spt* spt, void* va){
	struct page p;
	p.ua = pg_round_down(va);
	struct hash_elem* e = hash_find(&spt->page_table, &p.hash_elem);
	if(e == NULL)
		return NULL;
	struct page* res = hash_entry(e, struct page, hash_elem);
	return res;
}

bool page_insert(struct spt* spt, void* up, void* kp, bool w){
	struct page* page = malloc(sizeof(struct page));
	page->write = w;
	page->ua = pg_round_down(up);
	page->ka = kp;
	page->index = -1;
	page->present = true;
	page->rw = false;
	page->l = NULL;
	struct hash_elem* e = hash_insert(&(spt->page_table), &(page->hash_elem));
	if(e == NULL){
//		frame_insert(spt, up, kp);	
		return true;
	}
	return false;
}

struct page* frame_find(struct spt* spt, void* addr){
	struct page p;
	p.ka = addr;
	struct hash_elem* e = hash_find(&spt->frame_table, &p.hash_elem);
	if(e == NULL){
		return NULL;
	}
	return hash_entry(e, struct page, hash_elem);
}
bool frame_insert(struct spt* spt, void* up, void* kp){
	struct page* page = malloc(sizeof(struct page));
	page->ua = up;
	page->ka = kp;
	page->rw = false;
	struct hash_elem* e = hash_insert(&spt->frame_table, &page->hash_elem);
	if(e==NULL)
		return true;
	return false;
}


bool page_install (void *upage, void *kpage, bool writable)
{
  struct thread *t = thread_current ();
  /* Verify that there's not already a page at that virtual
     address, then map our page there. */
  bool res = (pagedir_get_page (t->pagedir, upage) == NULL && pagedir_set_page (t->pagedir, upage, kpage, writable));
  //res=res&& page_insert(t->spt, upage, kpage, writable);
  return res;
}

void page_rw_on(void* buffer, int size){
	struct thread* t = thread_current();
	struct spt* spt = t->spt;
	int cnt = size / (4*1024);
	void* buf = pg_round_down(buffer);
	for(int i=0;i<cnt;i++){
	//	struct page*  p = frame_find(spt, (void*)((uint32_t)buf + i* 4*1024));
	//	if(p!=NULL){
	//		p->rw = true;
	//	}
	}
}
void page_rw_off(void* buffer, int size){
	struct thread* t = thread_current();
	struct spt* spt = t->spt;
	int cnt = size / (4*1024);
	void* buf = pg_round_down(buffer);
	for(int i=0;i<cnt;i++){
	//	struct page* p = frame_find(spt, (void*)((uint32_t)buf + i*4*1024));
	//	if(p!=NULL){
	//		p->rw =false;
	//	}
	}
}
/*
void page_destroy(struct spt* spt, struct hash_elem *e){
        hash_delete(&spt->page_table, e);
}

void frame_destroy(struct spt* spt, struct hash_elem *e){
	hash_delete(&spt->frame_table, e);
}
*/
void evict_page(){
	struct thread* t = thread_current();
	//lock_acquire(&t->spt->evict_lock);
	struct thread* nowt = thread_current();
	if(t!=nowt){
		PANIC("evict different thread");
	}
	struct hash* nowh = &nowt->spt->page_table;
	struct hash_iterator nowi;

	hash_first(&nowi, nowh);
	while(hash_next(&nowi)){
		struct page* nowp = hash_entry(hash_cur(&nowi), struct page, hash_elem);
//		struct page* nowf =frame_find(nowt->spt, nowp->ua);	
		if(nowp->present == false){// || nowf->rw == true){
			continue;
		}
		else if( pagedir_is_accessed(t->pagedir, nowp->ua)) {
      			pagedir_set_accessed(t->pagedir, nowp->ua, false);
     	 		continue;
    		}

		swap_out(nowp, nowp->ua);
		palloc_free_page(nowp->ka);
//		struct page* f = frame_find(nowt->spt,nowp->ka);
//		if(f!=NULL)hash_delete(&nowt->spt->frame_table, &f->hash_elem);
	//	frame_destroy(t->spt, &nowp->hash_elem);
		if(nowp->index == -1){
			PANIC("evict error");
			exit(-1);
 		}
		//lock_release(&t->spt->evict_lock);
		return;
	}
	hash_first(&nowi, nowh);
	while(hash_next(&nowi)){
                struct page* nowp = hash_entry(hash_cur(&nowi), struct page, hash_elem);
	//	struct page* nowf =frame_find(nowt->spt, nowp->ua);
                if(nowp->present == false){// || nowf->rw == true){
                        continue;
                }
                  else if( pagedir_is_accessed(t->pagedir, nowp->ua)) {
                        pagedir_set_accessed(t->pagedir, nowp->ua, false);
                        continue;
                }
                swap_out(nowp, nowp->ua);
                palloc_free_page(nowp->ka);
//		struct page* f = frame_find(nowt->spt, nowp->ka);
 //               if(f!=NULL)hash_delete(&nowt->spt->frame_table, &f->hash_elem);
                if(nowp->index == -1){
                        PANIC("evict error");
                        exit(-1);
                }
                //lock_release(&t->spt->evict_lock);
                return;
        }

	PANIC("evict fail");
}

void swap_init(){
	sb = block_get_role(BLOCK_SWAP);
	//ASSERT(sb!=NULL);
	if(sb == NULL){
		PANIC("block not initialized..!");
	}
	//for(int i=0;i<1024;i++){
	//swap_space[i]= false;
	//}	
	//printf("[%d]\n", block_size(sb));
	//lock_init(&swap_lock);
}

void* swap_in(struct page* page, int idx){
	struct thread* t = thread_current();
        //struct block* sb = block_get_role(BLOCK_SWAP);
	ASSERT(page->index == idx);
	ASSERT(page->index != -1);
	lock_acquire(&t->spt->swap_in_lock);
        void* ka = palloc_get_page(PAL_USER);
        if(ka == NULL){
                evict_page();
                ka = palloc_get_page(PAL_USER);
		ASSERT(ka != NULL);
       }

	//lock_acquire(&swap_lock);
        for(int i=0;i<8;i++){
                block_read(sb, idx * 8 + i, ka + 512 * i);
        }
        swap_space[idx] = false;
        page->ka=ka;
        page->index = idx;
        page->present = true;
	page->ua = pg_round_down(page->ua);
        page_install(page->ua, page->ka, page->write);
//	frame_insert(t->spt, page->ua, page->ka);
	lock_release(&t->spt->swap_in_lock);
        return ka;
}

int swap_out(struct page* page, void* addr){
        //struct block* sb = block_get_role(BLOCK_SWAP);
	 struct thread* t = thread_current();
	lock_acquire(&t->spt->swap_out_lock);
	struct thread* nowt = thread_current();
	struct page* temp = page_find(nowt->spt, addr);
	if(page != temp || page->ka < PHYS_BASE){
		PANIC("swap out 1");
		//exit(-1);
	}	
	//lock_acquire(&swap_lock);
        int now = 0;

        while(swap_space[now] != false){// false =가 빈거 true가 찬거
                now++;
		if(now > 1024){
			PANIC("swap out 2");
			return -1;
		}
        }

        for(int i=0;i<8;i++){
                 block_write(sb, now * 8 + i, page->ka + 512 * i);
        }

        swap_space[now] = true;
	page->present = false;
	
	//page->write = true;
	page->index = now;
	pagedir_clear_page(nowt->pagedir, page->ua);
//      palloc_free_page(page->ka);
//        page->ka = NULL;
	lock_release(&t->spt->swap_out_lock);
	return now;
}


