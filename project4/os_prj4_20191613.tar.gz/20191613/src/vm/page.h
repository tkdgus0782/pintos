//#include <stdint.h>
//#include <debug.h>
#include <hash.h>
#include "threads/synch.h"
#include "threads/palloc.h"
#include "threads/malloc.h"
#include "threads/thread.h"
#include "userprog/pagedir.h"
#include "threads/vaddr.h"
#include "threads/interrupt.h"
#include "filesys/file.h"
struct spt{
	struct hash page_table;
	struct hash frame_table;
	struct lock frame_lock;
	struct lock evict_lock;
	struct lock swap_in_lock;
	struct lock swap_out_lock;
};

struct lazy{
	struct file* f;
       	int32_t ofs;
    	uint32_t read_bytes;
       	uint32_t zero_bytes;
};

struct page{
	struct hash_elem hash_elem;
	void* ka;//physical frame
	void* ua;//virtual addres
	int index;
	bool present;
	bool write;
	bool rw;
	struct lazy* l;
};

//struct lock swap_lock;
struct block* sb;
 
unsigned hash_page(const struct hash_elem* e, void* aux);//return hash
bool hash_less(const struct hash_elem* a, const struct hash_elem* b, void* aux);//a<B: true, else: false
struct page* page_find(struct spt*, void* addr);
struct spt* page_table_init(void);
bool page_insert(struct spt*, void*, void*, bool);
bool page_install(void*, void*, bool);
void evict_page(void);

bool lazy_load(struct spt*, struct file*, int32_t, void*, uint32_t, uint32_t, bool);
void* lazy_install(struct page* );

unsigned hash_frame(const struct hash_elem* e, void* aux);
struct page* frame_find(struct spt*, void* addr);
bool frame_insert(struct spt*, void*, void*);

bool swap_space[1024];//4mb/4kb == 1024
void swap_init(void);
int swap_out(struct page* page, void* addr);
void* swap_in(struct page* page, int idx);

void* get_pn(void*);

void page_rw_on(void*, int);
void page_rw_off(void*, int);
