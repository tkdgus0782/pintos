#define USERPROG_SYSCALL_H
#include "lib/user/syscall.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "lib/kernel/console.h"
#include "userprog/process.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
void syscall_init (void);

void cad(void*);

struct lock file_sync;
struct file{
	struct inode* inode;
	off_t pos;
	bool deny_write;
};

/*syscalls*/
void halt (void);
void exit (int status);
pid_t exec (const char *file);
int wait (pid_t);
bool create (const char *file, unsigned initial_size);
bool remove (const char *file);
int open (const char *file);
void close(int fd);
int filesize (int fd);
int read (int fd, void *buffer, unsigned length);
int write (int fd, const void *buffer, unsigned length);
void seek (int fd, unsigned position);
unsigned tell (int fd);
int fibonacci(int n);
int max_of_four_int(int a, int b, int c, int d);


