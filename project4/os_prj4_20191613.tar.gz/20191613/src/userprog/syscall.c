#include "userprog/syscall.h"
#include <stdio.h>
#include <stdlib.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "threads/synch.h"
#include <string.h>
#include "vm/page.h"

void cad(void*);
static void syscall_handler(struct intr_frame *);

void
syscall_init (void) 
{
	lock_init(&file_sync);	
	intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

/* check whether given address is user area;
otherwise exit process (i.e., inbetween 0x8048000~0xc0000000) */
void cad(void* ptr){
	if(!is_user_vaddr(ptr) || ptr == NULL || is_kernel_vaddr(ptr)){
			exit(-1);
	}
}

static void
syscall_handler (struct intr_frame *f) 
{
	//check whether esp and ptr are user space; otherwise page fault
	//getting syscall num from user stack
	thread_current()->stack = f->esp;	
	cad(f->esp);
	int scn = * (uint32_t *) f->esp;
	switch(scn){
		/*save return to eax*/
    		case SYS_HALT:
			halt();
			break;
			
		case SYS_EXIT:
			cad(f->esp + 4);
			exit(*(uint32_t *)(f->esp + 4));
			break;
			
		case SYS_EXEC:
			cad(f->esp+4);
			f->eax = exec((const char *)*(uint32_t *)(f->esp + 4));
			break;
			
		case SYS_WAIT:
			cad(f->esp+4);
			f->eax = wait((pid_t)*(uint32_t *)(f->esp + 4));
			break;
			
		case SYS_CREATE:
			cad(f->esp+4);
			cad(f->esp+8);
			f->eax = create((const char*)*(uint32_t *)(f->esp + 4), (unsigned)*(uint32_t *)(f->esp + 8));
			break;
			
		case SYS_REMOVE:
			cad(f->esp+4);
			f->eax = open((const char*)*(uint32_t *)(f->esp + 4));
			break;
			
		case SYS_OPEN:
			cad(f->esp+4);
			f->eax = open((const char*)*(uint32_t *)(f->esp + 4));
			break;
	
                case SYS_CLOSE:
                        cad(f->esp+4);
                        close((int)*(uint32_t *)(f->esp + 4));
                        break;
		
		case SYS_FILESIZE:
			cad(f->esp+4);
			f->eax = filesize((int)*(uint32_t *)(f->esp + 4));
			break;
			
		case SYS_READ:
			cad(f->esp + 4);
			cad(f->esp + 8);
			cad(f->esp + 12);
			f->eax = read((int)*(uint32_t *)(f->esp + 4), (void *)*(uint32_t *)(f->esp + 8), (unsigned)*((uint32_t *)(f->esp + 12)));
			break;
			
		case SYS_WRITE:
			cad(f->esp + 4);
			cad(f->esp+8);
			cad(f->esp+12);
			f->eax = write((int)*(uint32_t *)(f->esp + 4), (void *)*(uint32_t *)(f->esp + 8), (unsigned)*((uint32_t *)(f->esp + 12)));
			break;
			
		case SYS_SEEK:
			cad(f->esp+4);
			cad(f->esp+8);
			seek((unsigned)*(uint32_t *)(f->esp + 4), (unsigned)*(uint32_t *)(f->esp + 8));
			break;
			
		case SYS_TELL:
			cad(f->esp+4);
			f->eax = tell((int)*(uint32_t *)(f->esp + 4));
			break;
	
		case SYS_FIBONACCI:
			cad(f->esp + 4);
			f->eax = fibonacci((int)*(uint32_t *)(f->esp+4));
			break;
		case SYS_MAX_OF_FOUR_INT:

			f->eax = max_of_four_int((int)*(uint32_t *)(f->esp + 4), (int)*(uint32_t *)(f->esp + 8), 
					(int)*((uint32_t *)(f->esp + 12)),(int)*(uint32_t *)(f->esp + 16));
			break;
					
	}
}

void halt(void){
	shutdown_power_off();
}

void exit(int status){
	printf("%s: exit(%d)\n", thread_name(), status);
	thread_current()->exit_status = status;
//	lock_release(&file_sync);
	thread_exit();
}

/* create child process
uese process_execute in userprog/process.c */
pid_t exec (const char *file){
	return process_execute(file);
}

int wait (pid_t pid){
	return process_wait(pid);
}

int fibonacci(int n){
  
	int m1=0, now=1, temp;
 
      	for(int i = 1; i < n; i++){
		temp = now;
		now = now + m1;
		m1 = temp;
	}
	return now;
}

int max_of_four_int(int a, int b, int c, int d){
	int max = a;
	if(b > a){
		max = b;
	}
	if(c > max){
		max = c;
	}
	if(d > max){
		max = d;
	}
	return max;
}
///////proj 2
int read (int fd, void *buffer, unsigned size){
      	char temp;
	int res;
	cad(buffer);
	lock_acquire(&file_sync);
	if(fd == 0){
		char temp = input_getc();
		*(char*)buffer = temp;
		lock_release(&file_sync);
		return size;
	}
	else{
		struct file* now = find_file(fd);
      		if(now == NULL){
			exit(-1);
      			return -1;
      		}
		//page_rw_on(buffer, size);
		res = file_read(now, buffer, size);   
		//page_rw_off(buffer, size);
		lock_release(&file_sync);	
		return res;
	}
}

int write (int fd, const void *buffer, unsigned size){
	struct file* now;
	int res = -1;
	cad(buffer);
	lock_acquire(&file_sync);
	if (fd == 1) {
		putbuf(buffer, size);
		lock_release(&file_sync);
		return size;
	}
	now = find_file(fd);
	if(now == NULL || fd == 0){
		lock_release(&file_sync);
		exit(-1);
		return -1;
	}
	//page_rw_on(buffer, size);
	res = file_write(now, buffer, size);
	//page_rw_off(buffer, size);
	lock_release(&file_sync);
	return res;
}

bool create(const char* file, unsigned size){
	if(file == NULL){
		exit(-1);
		return -1;
	}
	return filesys_create(file, size);
}

bool remove(const char* file){
	return filesys_remove(file);
}

int open(const char* file){
	if(file == NULL){
		exit(-1);
		return -1;
	}
	lock_acquire(&file_sync);
	struct file* new_file = filesys_open(file);
	if(strcmp(file, thread_current()->name) == 0){
                file_deny_write(new_file);
        }
	if(new_file != NULL){
		lock_release(&file_sync);
		return plus_file(new_file);
	}
	else{
		lock_release(&file_sync);
//		exit(-1);
		return -1;
	}
}

void close(int fd){
	struct file* now = find_file(fd);
	//minus_file(fd);
	minus_file(fd);
}

int filesize(int fd){
	struct file* now = find_file(fd);
	if(now == NULL){
		exit(-1);
		return -1;
	}
	return file_length(now);
}

void seek(int fd, unsigned pos){
	struct file* now = find_file(fd);
	if(now == NULL){
		exit(-1);
		return;
	}
	file_seek(now, pos);
}

unsigned tell(int fd){
	struct file* now = find_file(fd);
	if(now == NULL){
		exit(-1);
		return 0;
	}
	return file_tell(now);
}

