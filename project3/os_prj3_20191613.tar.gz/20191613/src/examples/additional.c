#include <stdio.h>
#include <stdlib.h>
#include <syscall.h>

int
main (int argc, char **argv)
{
  int a = atoi(argv[1]);
  int b = atoi(argv[2]);
  int c = atoi(argv[3]);
  int d = atoi(argv[4]);

  int res1 = fibonacci(a);
  int res2 = max_of_four_int(a,b,c,d);

  printf("%d %d\n",res1, res2);

  return EXIT_SUCCESS;
}

